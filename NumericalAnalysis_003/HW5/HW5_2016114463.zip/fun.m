function F = fun(x)
F = [-x(1)^2+x(1)-x(2)+0.75;x(1)^2-5*x(1)*x(2)-x(2)];
