function F = fun2(x)
F = [x(1)^2+x(2)^2-5;x(1)^2-x(2)-1];
