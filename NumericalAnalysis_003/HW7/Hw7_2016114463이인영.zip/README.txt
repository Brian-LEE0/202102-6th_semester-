1번문제
Hw7_Prob1 실행

2번문제
RandomPoint_generator.m 실행후
prob2.m 실행