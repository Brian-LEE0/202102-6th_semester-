1,2번 문제;
Ad_List.h
Ad_Matrix.h
Graph_Queue.h
헤더사용

main2.c를 빌드
데이터 파일로는 input2.txt 사용

3,4번 문제;
Ad_Matrix3.h
헤더사용

main4.c를 빌드
데이터 파일로는 input4.txt 사용