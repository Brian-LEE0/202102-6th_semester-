공통 :
random_number_generator.c 를 컴파일해 list.txt를 만들거나
sample(list.txt, list2.txt)를 list로 사용한다.

1.
Hashed_Search.h
Binary_Search.h
Sort.h
Structure.h
main1.c
사용;

2.
Sort.h
main2.c
사용;

